insert into conference_room (room_Id,floor,name,size) values(1, 1, 'Amaze',3);
insert into conference_room (room_Id,floor,name,size) values(2, 2, 'Beauty', 7);
insert into conference_room (room_Id,floor,name,size) values(3, 3, 'Inspire', 12);
insert into conference_room (room_Id,floor,name,size) values(4, 4, 'Strive', 20);

insert into tuser values (1, 'ishusi', 'Ishu','Singhal');
insert into tuser values (2, 'amang',  'Aman','Gupta');

