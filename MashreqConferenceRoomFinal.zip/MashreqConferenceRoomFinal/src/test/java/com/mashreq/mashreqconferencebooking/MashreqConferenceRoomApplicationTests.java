package com.mashreq.mashreqconferencebooking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MashreqConferenceRoomApplicationTests {

	@Test
	void contextLoads() {
	}

}
