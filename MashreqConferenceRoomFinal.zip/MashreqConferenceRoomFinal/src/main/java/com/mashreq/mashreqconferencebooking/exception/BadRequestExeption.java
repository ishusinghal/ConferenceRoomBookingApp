package com.mashreq.mashreqconferencebooking.exception;

public class BadRequestExeption extends RuntimeException{

    public BadRequestExeption(String s) {
            super(s);
        }

}
